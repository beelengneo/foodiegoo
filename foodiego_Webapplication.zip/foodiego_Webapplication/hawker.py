from flask import Flask, redirect, url_for, render_template, request, session,flash
# from flask_sqlalchemy import SQLAlchemy
# from datetime import timedelta
from forms import RegisterForm
app = Flask(__name__)
# db = SQLAlchemy(app)

#
# class Hawker_List(db.Model):
#     hawker_name = db.Column()



# app.secret_key = "hello"
app.config['SECRET_KEY'] = '74724b089dc5aaee6d76ac22'

# app.permanent_session_lifetime = timedelta(minutes=5)

# @ signifies a decorator - way to wrap a function and modifying its behavior
@app.route("/")
@app.route("/home")
def home_page():
    return render_template("index.html")


@app.route("/hawker_centre_list")
def hawker_centre_list_page():
    items = [
    {'id': 1, 'hawker_name': 'Maxwell Food Centre', 'address': '1 Kadayanallur Street Singapore 069184', 'rating': 5.0},
    {'id': 2, 'hawker_name': 'Newton Food Centre', 'address': '500 Clemenceau Avenue North, Singapore 229495', 'rating': 4.0},
    {'id': 3, 'hawker_name': 'Old Airport Road Food Centre', 'address': 'Block 51 Old Airport Road, Singapore 390051', 'rating': 4.5}
    ]
    return render_template("hawker_centre_list_page.html", items=items)


@app.route('/register')
def register_page():
    form = RegisterForm()
    return render_template('register.html', form=form)


@app.route('/reserve_hawker-centre-table')
def reserve_table():
    return render_template('reserve_table.html')


















@app.route("/profile/<name>")
def profile(name):
    return render_template("profile.html", name=name)




@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        session.permanent = True
        user = request.form["nm"]
        session["user"] = user
        flash("Login Successful!")
        return redirect(url_for("user"))
    else:
        if "user" in session:
            flash("Already Logged In!")
            return redirect(url_for("user"))
        return render_template("login.html")


@app.route("/user")
def user():
    if "user" in session:
        user = session["user"]
        return render_template("user.html", user=user)
    else:
        flash("You are not logged In!")
        return redirect(url_for("login"))


@app.route("/logout")
def logout():
    flash("You have been logged out!", "info")
    session.pop("user", None)
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=True)

